from flask_sqlalchemy import SQLAlchemy
from .attributes import *

DB = SQLAlchemy()
