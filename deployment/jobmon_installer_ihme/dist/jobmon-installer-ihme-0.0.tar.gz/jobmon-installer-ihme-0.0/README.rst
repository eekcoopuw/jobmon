A jobmon client for IHME users
##############################

This package is intended for use by IHME staff who want to run jobmon workflow on IHME's internal clusters. It is preconfigured to use the correct jobmon server and installs the IHME specific plugins.
